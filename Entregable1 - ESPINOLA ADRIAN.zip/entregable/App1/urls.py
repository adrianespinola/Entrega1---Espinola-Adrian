from django.urls import path
from .views import *


urlpatterns = [
    path('area/', area, name='area'),
    path('juniors/', juniors, name='juniors'),
    path('seniors/', seniors, name='seniors'),
    path('',inicio, name='inicio'),
    path('areaFormulario/',areaFormulario, name='areaFormulario'),
    path('seniorFormulario/',seniorFormulario, name='seniorFormulario'),

]