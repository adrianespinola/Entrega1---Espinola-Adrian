from django.shortcuts import render
from django.http import HttpResponse
from App1.models import Area, Seniors
from App1.forms import SeniorForm



def inicio(request):
    return render(request, "App1/inicio.html")

def area(request):
    return render(request, "App1/area.html")

def juniors(request):
    return render(request, "App1/juniors.html")

def seniors(request):
    return render(request, "App1/seniors.html")


def areaFormulario(request):
    if(request.method=="POST"):
        nombre=request.POST.get("nombre")
        rubro=request.POST.get("rubro")
        area=Area(nombre=nombre, rubro=rubro)
        area.save()
        return render(request, "App1/inicio.html")
    
    return render(request, "App1/areaFormulario.html")



def seniorFormulario(request):
    if request.method=="POST":
        form= SeniorForm(request.POST)
        if form.is_valid():
            info= form.cleaned_data
            nombre= info["nombre"]
            apellido= info["apellido"]
            email= info["email"]
            senior= Senior(nombre=nombre, apellido=apellido, email=email)
            senior.save()
            return render (request, "App1/inicio.html")
    else:
        form= SeniorForm()
    return render(request,"App1/seniorForm.html"), {"formulario":form}