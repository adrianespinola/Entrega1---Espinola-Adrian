from django.db import models

class Juniors(models.Model):
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    email = models.EmailField()

    def __str__(self):
        return self.nombre+" "+self.apellido

class Seniors(models.Model):
    nombre = models.CharField(max_length=50)
    apellido = models.CharField(max_length=50)
    email = models.EmailField()

    def __str__(self):
        return self.nombre+" "+self.apellido

class Area(models.Model):
    nombre = models.CharField(max_length=50)
    rubro = models.CharField(max_length=50)
    
    def __str__(self):
        return self.nombre+" "+self.rubro